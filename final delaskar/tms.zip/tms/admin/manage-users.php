<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
{	
    header('location:index.php');
}
else{ 
?>
<!DOCTYPE HTML>
<html>
<head>
<title>TMS | Admin gestionar usuarios</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link rel="stylesheet" href="css/morris.css" type="text/css"/>
<!-- Graph CSS -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- jQuery -->
<script src="js/jquery-2.1.4.min.js"></script>
<!-- //jQuery -->
<!-- tables -->
<link rel="stylesheet" type="text/css" href="css/table-style.css" />
<link rel="stylesheet" type="text/css" href="css/basictable.css" />
<script type="text/javascript" src="js/jquery.basictable.min.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
      $('#table').basictable();
      $('#table-auditoria').basictable();

      $('#table-breakpoint').basictable({
        breakpoint: 768
      });

      $('#table-swap-axis').basictable({
        swapAxis: true
      });

      $('#table-force-off').basictable({
        forceResponsive: false
      });

      $('#table-no-resize').basictable({
        noResize: true
      });

      $('#table-two-axis').basictable();

      $('#table-max-height').basictable({
        tableWrapper: true
      });
    });
</script>
<!-- //tables -->
<link href='//fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'/>
<link href='//fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<!-- lined-icons -->
<link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
<!-- //lined-icons -->

<style>
    .status-bloqueado { color: #ff0000; font-weight: bold; }
    .status-activo { color: #008000; font-weight: bold; }
    .badge { padding: 3px 8px; border-radius: 12px; font-size: 12px; }
    .badge-danger { background-color: #dc3545; color: white; }
    .badge-success { background-color: #28a745; color: white; }
    .badge-warning { background-color: #ffc107; color: black; }
</style>
</head> 
<body>
   <div class="page-container">
   <!--/content-inner-->
<div class="left-content">
	   <div class="mother-grid-inner">
            <!--header start here-->
				<?php include('includes/header.php');?>
				     <div class="clearfix"> </div>	
				</div>
<!--heder end here-->
<ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="index.html">Inicio</a><i class="fa fa-angle-right"></i>Administrar usuarios</li>
</ol>

<div class="agile-grids">	
    <!-- tables -->
    <div class="agile-tables">
        <div class="w3l-table-info">
            <h2>Administrar usuarios</h2>
            <table id="table">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Nombre</th>
                    <th>No. Celular</th>
                    <th>Email</th>
                    <th>Estado</th>
                    <th>Intentos de login</th>
                    <th>Bloqueado hasta</th>
                    <th>Fecha de registro</th>
                    <th>Fecha de actualización</th>
                  </tr>
                </thead>
                <tbody>
                <?php 
                $sql = "SELECT * FROM tblusers";
                $query = $dbh->prepare($sql);
                $query->execute();
                $results = $query->fetchAll(PDO::FETCH_OBJ);
                $cnt = 1;
                if($query->rowCount() > 0) {
                    foreach($results as $result) { 
                        // Determinar estado de la cuenta
                        $estado = "Activo";
                        $clase_estado = "status-activo";
                        $badge_class = "badge-success";
                        
                        if ($result->account_locked_until !== NULL) {
                            $bloqueado_hasta = new DateTime($result->account_locked_until);
                            $ahora = new DateTime();
                            if ($bloqueado_hasta > $ahora) {
                                $estado = "Bloqueado";
                                $clase_estado = "status-bloqueado";
                                $badge_class = "badge-danger";
                            }
                        }
                        
                        if ($result->login_attempts >= 3) {
                            $badge_class = "badge-warning";
                        }
                ?>		
                    <tr>
                        <td><?php echo htmlentities($cnt);?></td>
                        <td><?php echo htmlentities($result->FullName ?? 'N/A');?></td>
                        <td><?php echo htmlentities($result->MobileNumber ?? 'N/A');?></td>
                        <td><?php echo htmlentities($result->EmailId ?? 'N/A');?></td>
                        <td><span class="badge <?php echo $badge_class; ?>"><?php echo $estado; ?></span></td>
                        <td><?php echo htmlentities($result->login_attempts);?></td>
                        <td><?php echo $result->account_locked_until ? htmlentities($result->account_locked_until) : 'No bloqueado';?></td>
                        <td><?php echo htmlentities($result->RegDate);?></td>
                        <td><?php echo htmlentities($result->UpdationDate ?? 'No actualizado');?></td>
                    </tr>
                <?php 
                    $cnt++;
                    } 
                } 
                ?>
                </tbody>
            </table>
        </div>
        
        <!-- Tabla de Auditoría -->
        <div class="w3l-table-info" style="margin-top: 30px;">
            <h2>Registro de Auditoría - Intentos de Login</h2>
            <table id="table-auditoria">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Usuario</th>
                    <th>Email</th>
                    <th>Último intento</th>
                    <th>Intentos fallidos</th>
                    <th>Estado bloqueo</th>
                    <th>IP (si está disponible)</th>
                  </tr>
                </thead>
                <tbody>
                <?php 
                // Consulta para la auditoría
                $sql_auditoria = "SELECT id, FullName, EmailId, UpdationDate, login_attempts, account_locked_until 
                                 FROM tblusers 
                                 WHERE login_attempts > 0 OR account_locked_until IS NOT NULL 
                                 ORDER BY UpdationDate DESC";
                $query_auditoria = $dbh->prepare($sql_auditoria);
                $query_auditoria->execute();
                $auditoria_results = $query_auditoria->fetchAll(PDO::FETCH_OBJ);
                $cnt_audit = 1;
                
                if($query_auditoria->rowCount() > 0) {
                    foreach($auditoria_results as $audit) { 
                        $estado_audit = "Normal";
                        $clase_audit = "badge-success";
                        
                        if ($audit->account_locked_until !== NULL) {
                            $bloqueado_hasta = new DateTime($audit->account_locked_until);
                            $ahora = new DateTime();
                            if ($bloqueado_hasta > $ahora) {
                                $estado_audit = "BLOQUEADO";
                                $clase_audit = "badge-danger";
                            } else {
                                $estado_audit = "Bloqueo expirado";
                                $clase_audit = "badge-warning";
                            }
                        } elseif ($audit->login_attempts >= 2) {
                            $estado_audit = "Alerta";
                            $clase_audit = "badge-warning";
                        }
                ?>		
                    <tr>
                        <td><?php echo htmlentities($cnt_audit);?></td>
                        <td><?php echo htmlentities($audit->FullName ?? 'Usuario incompleto');?></td>
                        <td><?php echo htmlentities($audit->EmailId ?? 'N/A');?></td>
                        <td><?php echo htmlentities($audit->UpdationDate ?? 'No registrado');?></td>
                        <td>
                            <span class="badge <?php echo $audit->login_attempts >= 3 ? 'badge-danger' : 'badge-warning'; ?>">
                                <?php echo htmlentities($audit->login_attempts);?> intentos
                            </span>
                        </td>
                        <td><span class="badge <?php echo $clase_audit; ?>"><?php echo $estado_audit; ?></span></td>
                        <td>Registro no disponible</td>
                    </tr>
                <?php 
                    $cnt_audit++;
                    } 
                } else {
                    echo '<tr><td colspan="7" style="text-align: center;">No hay registros de auditoría disponibles</td></tr>';
                }
                ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- script-for sticky-nav -->
<script>
$(document).ready(function() {
    var navoffeset = $(".header-main").offset().top;
    $(window).scroll(function(){
        var scrollpos = $(window).scrollTop(); 
        if(scrollpos >= navoffeset){
            $(".header-main").addClass("fixed");
        } else {
            $(".header-main").removeClass("fixed");
        }
    });
});
</script>
<!-- /script-for sticky-nav -->

<!--inner block start here-->
<div class="inner-block">
</div>
<!--inner block end here-->

<!--copy rights start here-->
<?php include('includes/footer.php');?>
<!--COPY rights end here-->
</div>
</div>
<!--//content-inner-->
<!--/sidebar-menu-->
<?php include('includes/sidebarmenu.php');?>
<div class="clearfix"></div>		
</div>
<script>
var toggle = true;
$(".sidebar-icon").click(function() {                
    if (toggle) {
        $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
        $("#menu span").css({"position":"absolute"});
    } else {
        $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
        setTimeout(function() {
            $("#menu span").css({"position":"relative"});
        }, 400);
    }
    toggle = !toggle;
});
</script>
<!--js -->
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>
<!-- /Bootstrap Core JavaScript -->	   
</body>
</html>
<?php } ?>