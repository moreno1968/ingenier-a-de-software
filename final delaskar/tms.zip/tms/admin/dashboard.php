<?php
session_start();
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
{	
    header('location:index.php');
}
else{
?>
<!DOCTYPE HTML>
<html>
<head>
<title>TMS | Panel de administración</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link rel="stylesheet" href="css/morris.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<script src="js/jquery-2.1.4.min.js"></script>
<link href='//fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'/>
<link href='//fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />

<style>
:root {
    --verde-selva: #2E8B57;
    --verde-tropical: #3CB371;
    --azul-oceano: #1E90FF;
    --azul-cielo: #87CEEB;
    --arena: #F4A460;
    --cascada: #40E0D0;
    --tierra: #8B4513;
    --flor: #FF69B4;
    --hoja: #32CD32;
    --sol: #FFD700;
}

/* Estilos para paneles con temática natural */
.panel {
    border: 1px solid #2E8B57;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(46, 139, 87, 0.1);
    background: linear-gradient(to bottom, #ffffff, #f8fff8);
    margin-bottom: 20px;
}
.panel-default {
    border-color: #2E8B57;
}
.panel-default > .panel-heading {
    color: #2E8B57;
    background: linear-gradient(to right, #f0fff0, #e0f7e0);
    border-color: #2E8B57;
    font-weight: bold;
    font-size: 16px;
}
.panel-heading {
    padding: 12px 15px;
    border-bottom: 1px solid #2E8B57;
    border-top-left-radius: 7px;
    border-top-right-radius: 7px;
}
.panel-body {
    padding: 15px;
    background-color: #fafffa;
}

/* Estilos para las tarjetas de estadísticas */
.four-grids {
    margin-bottom: 30px;
}
.four-agileits, .four-agileinfo, .four-w3ls, .four-wthree {
    background: linear-gradient(135deg, #e8f5e9, #c8e6c9);
    border-radius: 8px;
    border-left: 4px solid #2E8B57;
    padding: 15px;
    text-align: center;
    transition: transform 0.3s ease;
}
.four-agileits:hover, .four-agileinfo:hover, .four-w3ls:hover, .four-wthree:hover {
    transform: translateY(-5px);
    box-shadow: 0 5px 15px rgba(46, 139, 87, 0.3);
}
.four-agileits .icon, .four-agileinfo .icon, .four-w3ls .icon, .four-wthree .icon {
    background-color: #2E8B57;
    width: 60px;
    height: 60px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 15px;
    color: white;
    font-size: 24px;
}
.four-text h3 {
    color: #2E8B57;
    font-size: 14px;
    margin-bottom: 5px;
    font-weight: bold;
}
.four-text h4 {
    color: #1E90FF;
    font-size: 24px;
    font-weight: bold;
    margin: 0;
}

/* Mejoras en la gráfica de líneas para consultas */
.morris-hover {
    background: rgba(46, 139, 87, 0.9) !important;
    border: 1px solid #2E8B57 !important;
    color: white !important;
    border-radius: 5px !important;
}

/* Colores para las barras en gráficas de barras */
.morris-bar {
    stroke: #2E8B57;
}

/* Estilos para las gráficas */
.chart-container {
    position: relative;
    height: 250px;
}

.row {
    margin-bottom: 20px;
}

/* Estilo para el breadcrumb */
.breadcrumb {
    background-color: #f0fff0;
    border-radius: 5px;
    border-left: 4px solid #2E8B57;
}

.breadcrumb a {
    color: #2E8B57;
}

/* Títulos de sección */
.panel-title {
    color: #2E8B57;
    font-weight: bold;
}

.panel-title i {
    margin-right: 8px;
}
</style>

</head> 
<body>
   <div class="page-container">

<div class="left-content">
	   <div class="mother-grid-inner">

<?php include('includes/header.php');?>

		<ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Inicio</a> <i class="fa fa-angle-right"></i></li>
            </ol>

		<div class="four-grids">
					<div class="col-md-3 four-grid">
						<div class="four-agileits">
							<div class="icon">
								<i class="glyphicon glyphicon-user" aria-hidden="true"></i>
							</div>
							<div class="four-text">
								<h3>USUARIOS</h3>
								<?php 
								$sql = "SELECT id from tblusers";
								$query = $dbh -> prepare($sql);
								$query->execute();
								$results=$query->fetchAll(PDO::FETCH_OBJ);
								$cnt=$query->rowCount();
								?>			
								<h4> <?php echo htmlentities($cnt);?> </h4>
							</div>
						</div>
					</div>
					<div class="col-md-3 four-grid">
						<div class="four-agileinfo">
							<div class="icon">
								<i class="glyphicon glyphicon-list-alt" aria-hidden="true"></i>
							</div>
							<div class="four-text">
								<h3>FAVORITOS</h3>
								<?php 
								$sql1 = "SELECT BookingId from tblbooking";
								$query1 = $dbh -> prepare($sql1);
								$query1->execute();
								$results1=$query1->fetchAll(PDO::FETCH_OBJ);
								$cnt1=$query1->rowCount();
								?>
								<h4><?php echo htmlentities($cnt1);?></h4>
							</div>
						</div>
					</div>
					<div class="col-md-3 four-grid">
						<div class="four-w3ls">
							<div class="icon">
								<i class="glyphicon glyphicon-folder-open" aria-hidden="true"></i>
							</div>
							<div class="four-text">
								<h3>CONSULTAS</h3>
								<?php 
								$sql2 = "SELECT id from tblenquiry";
								$query2= $dbh -> prepare($sql2);
								$query2->execute();
								$results2=$query2->fetchAll(PDO::FETCH_OBJ);
								$cnt2=$query2->rowCount();
								?>
								<h4><?php echo htmlentities($cnt2);?></h4>
							</div>
						</div>
					</div>
					<div class="col-md-3 four-grid">
						<div class="four-wthree">
							<div class="icon">
								<i class="glyphicon glyphicon-briefcase" aria-hidden="true"></i>
							</div>
							<div class="four-text">
								<h3>SITIOS TOTALES</h3>
								<?php 
								$sql3 = "SELECT PackageId from tbltourpackages";
								$query3= $dbh -> prepare($sql3);
								$query3->execute();
								$results3=$query3->fetchAll(PDO::FETCH_OBJ);
								$cnt3=$query3->rowCount();
								?>
								<h4><?php echo htmlentities($cnt3);?></h4>
							</div>
						</div>
					</div>
					<div class="clearfix"></div>
				</div>
				<div class="four-grids">
					<div class="col-md-3 four-grid">
						<div class="four-w3ls">
							<div class="icon">
								<i class="glyphicon glyphicon-folder-open" aria-hidden="true"></i>
							</div>
							<div class="four-text">
								<h3>PROBLEMAS REPORTADOS</h3>
								<?php 
								$sql5 = "SELECT id from tblissues";
								$query5= $dbh -> prepare($sql5);
								$query5->execute();
								$results5=$query5->fetchAll(PDO::FETCH_OBJ);
								$cnt5=$query5->rowCount();
								?>
								<h4><?php echo htmlentities($cnt5);?></h4>
							</div>
						</div>
					</div>
					<div class="clearfix"></div>
				</div>

		<!-- Nuevas gráficas -->
		<div class="row">
			<!-- Gráfica de tipos de paquetes -->
			<div class="col-md-6">
				<div class="panel panel-default">
					<div class="panel-heading">
						<h3 class="panel-title"><i class="glyphicon glyphicon-stats"></i> TIPOS DE SITIOS TURÍSTICOS</h3>
					</div>
					<div class="panel-body">
						<div id="package-types-chart" class="chart-container"></div>
					</div>
				</div>
			</div>

			<!-- Gráfica de estado de reservas -->
			<div class="col-md-6">
				<div class="panel panel-default">
					<div class="panel-heading">
						<h3 class="panel-title"><i class="glyphicon glyphicon-list-alt"></i> FAVORITOS</h3>
					</div>
					<div class="panel-body">
						<div id="booking-status-chart" class="chart-container"></div>
					</div>
				</div>
			</div>
		</div>

		<!-- Gráfica de consultas por mes -->
		<div class="row">
			<div class="col-md-12">
				<div class="panel panel-default">
					<div class="panel-heading">
						<h3 class="panel-title"><i class="glyphicon glyphicon-time"></i> CONSULTAS POR MES (ÚLTIMOS 6 MESES)</h3>
					</div>
					<div class="panel-body">
						<div id="enquiries-chart" style="height: 300px;"></div>
					</div>
				</div>
			</div>
		</div>

		<!-- Gráfica de problemas -->
		<div class="row">
			<div class="col-md-6">
				<div class="panel panel-default">
					<div class="panel-heading">
						<h3 class="panel-title"><i class="glyphicon glyphicon-warning-sign"></i> PROBLEMAS REPORTADOS</h3>
					</div>
					<div class="panel-body">
						<div id="issues-chart" class="chart-container"></div>
					</div>
				</div>
			</div>

			<!-- Gráfica de usuarios registrados por mes -->
			<div class="col-md-6">
				<div class="panel panel-default">
					<div class="panel-heading">
						<h3 class="panel-title"><i class="glyphicon glyphicon-user"></i> USUARIOS REGISTRADOS POR MES</h3>
					</div>
					<div class="panel-body">
						<div id="users-chart" class="chart-container"></div>
					</div>
				</div>
			</div>
		</div>

<div class="inner-block">
</div>

<?php include('includes/footer.php');?>
</div>
</div>

<?php include('includes/sidebarmenu.php');?>
<div class="clearfix"></div>		
</div>

<script>
var toggle = true;
$(".sidebar-icon").click(function() {                
	if (toggle) {
		$(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
		$("#menu span").css({"position":"absolute"});
	} else {
		$(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
		setTimeout(function() {
			$("#menu span").css({"position":"relative"});
		}, 400);
	}
	toggle = !toggle;
});
</script>

<!--js -->
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/raphael-min.js"></script>
<script src="js/morris.js"></script>

<script>
$(document).ready(function() {
    
    // Datos para gráfica de tipos de paquetes
    <?php
    $sql_packages = "SELECT PackageType as label, COUNT(*) as value 
                    FROM tbltourpackages 
                    GROUP BY PackageType";
    $query_packages = $dbh->prepare($sql_packages);
    $query_packages->execute();
    $package_types = $query_packages->fetchAll(PDO::FETCH_ASSOC);
    ?>
    
    var packageData = [
        <?php foreach($package_types as $type): ?>
        { label: "<?php echo $type['label']; ?>", value: <?php echo $type['value']; ?> },
        <?php endforeach; ?>
    ];
    
    Morris.Donut({
        element: 'package-types-chart',
        data: packageData,
        colors: ['#2E8B57', '#3CB371', '#1E90FF', '#F4A460', '#40E0D0', '#32CD32'],
        formatter: function (y) { return y + ' sitios' },
        resize: true
    });

    // Datos para gráfica de estado de reservas
    <?php
    $sql_bookings = "SELECT 
                    CASE 
                        WHEN status = 1 THEN 'Confirmadas'
                        WHEN status = 0 THEN 'favoritos'
                        ELSE 'Canceladas'
                    END as label,
                    COUNT(*) as value 
                    FROM tblbooking 
                    GROUP BY status";
    $query_bookings = $dbh->prepare($sql_bookings);
    $query_bookings->execute();
    $booking_status = $query_bookings->fetchAll(PDO::FETCH_ASSOC);
    ?>
    
    var bookingData = [
        <?php foreach($booking_status as $status): ?>
        { label: "<?php echo $status['label']; ?>", value: <?php echo $status['value']; ?> },
        <?php endforeach; ?>
    ];
    
    Morris.Donut({
        element: 'booking-status-chart',
        data: bookingData,
        colors: ['#3CB371', '#FFD700', '#FF6347'],
        formatter: function (y) { return y + ' sitios' },
        resize: true
    });

    // Datos para gráfica de consultas por mes
    <?php
    $sql_enquiries = "SELECT 
                    DATE_FORMAT(PostingDate, '%Y-%m') as month,
                    COUNT(*) as enquiries
                    FROM tblenquiry 
                    WHERE PostingDate >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
                    GROUP BY DATE_FORMAT(PostingDate, '%Y-%m')
                    ORDER BY month";
    $query_enquiries = $dbh->prepare($sql_enquiries);
    $query_enquiries->execute();
    $enquiries_data = $query_enquiries->fetchAll(PDO::FETCH_ASSOC);
    
    // Formatear los meses para mejor presentación
    $enquiries_formatted = array();
    foreach($enquiries_data as $data) {
        $enquiries_formatted[] = array(
            'month' => date('M Y', strtotime($data['month'] . '-01')),
            'enquiries' => $data['enquiries']
        );
    }
    ?>
    
    var enquiriesData = [
        <?php foreach($enquiries_formatted as $data): ?>
        { month: "<?php echo $data['month']; ?>", enquiries: <?php echo $data['enquiries']; ?> },
        <?php endforeach; ?>
    ];
    
    Morris.Line({
        element: 'enquiries-chart',
        data: enquiriesData,
        xkey: 'month',
        ykeys: ['enquiries'],
        labels: ['Consultas'],
        lineColors: ['#1E90FF'],
        pointFillColors: ['#40E0D0'],
        pointStrokeColors: ['#1E90FF'],
        pointSize: 5,
        hideHover: 'auto',
        resize: true,
        parseTime: false,
        smooth: true,
        gridTextColor: '#2E8B57',
        lineWidth: 2
    });

    // Datos para gráfica de problemas
    <?php
    $sql_issues = "SELECT 
                    CASE 
                        WHEN AdminRemark IS NOT NULL THEN 'Resueltos'
                        ELSE 'Pendientes'
                    END as label,
                    COUNT(*) as value 
                    FROM tblissues 
                    GROUP BY CASE 
                        WHEN AdminRemark IS NOT NULL THEN 'Resueltos'
                        ELSE 'Pendientes'
                    END";
    $query_issues = $dbh->prepare($sql_issues);
    $query_issues->execute();
    $issues_data = $query_issues->fetchAll(PDO::FETCH_ASSOC);
    ?>
    
    var issuesData = [
        <?php foreach($issues_data as $issue): ?>
        { label: "<?php echo $issue['label']; ?>", value: <?php echo $issue['value']; ?> },
        <?php endforeach; ?>
    ];
    
    Morris.Donut({
        element: 'issues-chart',
        data: issuesData,
        colors: ['#3CB371', '#FF6347'],
        formatter: function (y) { return y + ' problemas' },
        resize: true
    });

    // Datos para gráfica de usuarios por mes
    <?php
    $sql_users = "SELECT 
                    DATE_FORMAT(RegDate, '%Y-%m') as month,
                    COUNT(*) as users
                    FROM tblusers 
                    WHERE RegDate >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
                    GROUP BY DATE_FORMAT(RegDate, '%Y-%m')
                    ORDER BY month";
    $query_users = $dbh->prepare($sql_users);
    $query_users->execute();
    $users_data = $query_users->fetchAll(PDO::FETCH_ASSOC);
    
    // Formatear los meses para mejor presentación
    $users_formatted = array();
    foreach($users_data as $data) {
        $users_formatted[] = array(
            'month' => date('M Y', strtotime($data['month'] . '-01')),
            'users' => $data['users']
        );
    }
    ?>
    
    var usersData = [
        <?php foreach($users_formatted as $data): ?>
        { month: "<?php echo $data['month']; ?>", users: <?php echo $data['users']; ?> },
        <?php endforeach; ?>
    ];
    
    Morris.Bar({
        element: 'users-chart',
        data: usersData,
        xkey: 'month',
        ykeys: ['users'],
        labels: ['Usuarios'],
        barColors: ['#40E0D0'],
        barFillColors: ['#87CEEB'],
        barOpacity: 0.8,
        barRadius: [3, 3, 0, 0],
        hideHover: 'auto',
        resize: true,
        gridTextColor: '#2E8B57',
        xLabelAngle: 45
    });

});
</script>
</body>
</html>
<?php } ?>