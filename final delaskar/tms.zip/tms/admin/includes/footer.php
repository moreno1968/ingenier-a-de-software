<div class="copyrights">
	 <p>© 2025 TMS. Reservados todos los derechos |  <a href="#">TMS</a> </p>
</div>	
