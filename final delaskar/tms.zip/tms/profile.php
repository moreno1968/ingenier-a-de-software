<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['login'])==0)
	{	
header('location:index.php');
}
else{
if(isset($_POST['submit6']))
	{
$name=$_POST['name'];
$mobileno=$_POST['mobileno'];
$email=$_SESSION['login'];

$sql="update tblusers set FullName=:name,MobileNumber=:mobileno where EmailId=:email";
$query = $dbh->prepare($sql);
$query->bindParam(':name',$name,PDO::PARAM_STR);
$query->bindParam(':mobileno',$mobileno,PDO::PARAM_STR);
$query->bindParam(':email',$email,PDO::PARAM_STR);
$query->execute();
$msg="Profile Updated Successfully";
}

?>
<!DOCTYPE HTML>
<html>
<head>
<title>TMS | Sistema de Gestión Turística</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Tourism Management System In PHP" />
<script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
<link href="css/font-awesome.css" rel="stylesheet">
<!-- Custom Theme files -->
<script src="js/jquery-1.12.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>

  <style>
		.errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}

/* Estilos para la nueva estructura */
.profile-container {
    display: flex;
    flex-wrap: wrap;
    gap: 30px;
    margin-top: 20px;
}

.profile-form-container {
    flex: 1;
    min-width: 350px;
}

.profile-gallery {
    flex: 1;
    min-width: 350px;
}

.gallery-title {
    font-size: 1.5rem;
    margin-bottom: 20px;
    color: #333;
    border-bottom: 2px solid #337ab7;
    padding-bottom: 10px;
}

.gallery-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 15px;
}

.gallery-item {
    background: white;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    transition: transform 0.3s ease;
}

.gallery-item:hover {
    transform: translateY(-5px);
}

.gallery-item img {
    width: 100%;
    height: 150px;
    object-fit: cover;
    display: block;
}

.gallery-info {
    padding: 15px;
}

.gallery-info h4 {
    font-size: 1.1rem;
    margin-bottom: 8px;
    color: #337ab7;
}

.gallery-info p {
    font-size: 0.9rem;
    color: #666;
    line-height: 1.4;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    margin-bottom: 8px;
    font-weight: bold;
    color: #333;
}

.form-control {
    width: 100%;
    padding: 10px 15px;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-size: 1rem;
}

.info-text {
    background: #f8f9fa;
    padding: 12px 15px;
    border-radius: 4px;
    margin-bottom: 15px;
    border-left: 4px solid #337ab7;
}

/* Responsive */
@media (max-width: 768px) {
    .profile-container {
        flex-direction: column;
    }
    
    .gallery-grid {
        grid-template-columns: 1fr;
    }
    
    .profile-form-container, .profile-gallery {
        width: 100%;
    }
}
		</style>
</head>
<body>
<!-- top-header -->
<div class="top-header">
<?php include('includes/header.php');?>

<!--- /banner-1 ---->
<!--- privacy ---->
<div class="privacy">
	<div class="container">
		<h3 class="wow fadeInDown animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;">Mi Perfil!!</h3>
		
		<div class="profile-container">
			<div class="profile-form-container">
				<form name="chngpwd" method="post">
				 <?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
						else if($msg){?><div class="succWrap"><strong>EXITOSO</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>

	<?php 
	$useremail=$_SESSION['login'];
	$sql = "SELECT * from tblusers where EmailId=:useremail";
	$query = $dbh -> prepare($sql);
	$query -> bindParam(':useremail',$useremail, PDO::PARAM_STR);
	$query->execute();
	$results=$query->fetchAll(PDO::FETCH_OBJ);
	$cnt=1;
	if($query->rowCount() > 0)
	{
	foreach($results as $result)
	{	?>

		<div class="form-group">
			<label for="name">Nombre</label>
			<input type="text" name="name" value="<?php echo htmlentities($result->FullName);?>" class="form-control" id="name" required>
		</div>

		<div class="form-group">
			<label for="mobileno">Número de teléfono móvil</label>
			<input type="text" class="form-control" name="mobileno" maxlength="10" value="<?php echo htmlentities($result->MobileNumber);?>" id="mobileno" required>
		</div>

		<div class="form-group">
			<label for="email">Correo</label>
			<input type="email" class="form-control" name="email" value="<?php echo htmlentities($result->EmailId);?>" id="email" readonly>
		</div>

		<div class="info-text">
			<strong>Fecha de última actualización:</strong><br>
			<?php echo htmlentities($result->UpdationDate);?>
		</div>

		<div class="info-text">
			<strong>Fecha de registro:</strong><br>
			<?php echo htmlentities($result->RegDate);?>
		</div>

	<?php }} ?>

					<div class="form-group">
						<button type="submit" name="submit6" class="btn-primary btn">Actualizar</button>
					</div>
				</form>
			</div>
			
			<div class="profile-gallery">
				<h3 class="gallery-title">Destinos Populares</h3>
				<div class="gallery-grid">
					<div class="gallery-item wow fadeInRight animated" data-wow-delay="0.2s">
						<img src="https://images.unsplash.com/photo-1469474968028-56623f02e42e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80" alt="Paisaje natural">
						<div class="gallery-info">
							<h4>Aventura en la Naturaleza</h4>
							<p>Descubre los paisajes más impresionantes con nuestras rutas personalizadas.</p>
						</div>
					</div>
					
					<div class="gallery-item wow fadeInRight animated" data-wow-delay="0.4s">
						<img src="https://images.unsplash.com/photo-1488646953014-85cb44e25828?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80" alt="Ciudad histórica">
						<div class="gallery-info">
							<h4>Ciudades con Historia</h4>
							<p>Sumérgete en la cultura de destinos urbanos fascinantes.</p>
						</div>
					</div>
					
					<div class="gallery-item wow fadeInRight animated" data-wow-delay="0.6s">
						<img src="https://images.unsplash.com/photo-1507525428034-b723cf961d3e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80" alt="Playa tropical">
						<div class="gallery-info">
							<h4>Playas Paradisíacas</h4>
							<p>Relájate en las playas más hermosas del mundo.</p>
						</div>
					</div>
					
					<div class="gallery-item wow fadeInRight animated" data-wow-delay="0.8s">
						<img src="https://images.unsplash.com/photo-1551632811-561732d1e306?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80" alt="Aventura en montaña">
						<div class="gallery-info">
							<h4>Montañas Impresionantes</h4>
							<p>Vive experiencias únicas con rutas de senderismo y escalada.</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php include('includes/footer.php');?>

<?php include('includes/signup.php');?>			
<!-- //signu -->
<!-- signin -->
<?php include('includes/signin.php');?>			
<!-- //signin -->
<!-- write us -->
<?php include('includes/write-us.php');?>
</body>
</html>
<?php } ?>