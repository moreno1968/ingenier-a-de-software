<?php
session_start();
include('includes/config.php'); // Asegúrate de que tu conexión PDO esté configurada aquí

if (isset($_POST['signin'])) {
    $email = $_POST['email'];
    $password = md5($_POST['password']);

    // Verificar si el usuario existe
    $sql = "SELECT id, Password, login_attempts, account_locked_until 
            FROM tblusers WHERE EmailId = :email";
    $query = $dbh->prepare($sql);
    $query->bindParam(':email', $email, PDO::PARAM_STR);
    $query->execute();
    $user = $query->fetch(PDO::FETCH_OBJ);

    if ($user) {
        // Verificar si está bloqueado
        if ($user->account_locked_until && strtotime($user->account_locked_until) > time()) {
            $remaining = round((strtotime($user->account_locked_until) - time()) / 60);
            if ($remaining < 4) $remaining = "<4"; // Mostrar menos de 1 minuto
            echo "<script>alert('Cuenta bloqueada. Intenta nuevamente en $remaining minuto(s).');</script>";
        } else {
            // Verificar contraseña
            if ($user->Password == $password) {
                // Reiniciar intentos y desbloquear
                $reset = "UPDATE tblusers 
                          SET login_attempts = 0, account_locked_until = NULL 
                          WHERE id = :id";
                $stmt = $dbh->prepare($reset);
                $stmt->bindParam(':id', $user->id, PDO::PARAM_INT);
                $stmt->execute();

                $_SESSION['login'] = $email;
                echo "<script type='text/javascript'> document.location = 'package-list.php'; </script>";
            } else {
                // Contraseña incorrecta
                $new_attempts = $user->login_attempts + 1;
                $lock_time = null;

                if ($new_attempts >= 3) {
                    // Bloqueo temporal de 1 minuto
                    $lock_time = date("Y-m-d H:i:s", strtotime("+1 minute"));
                    echo "<script>alert('Demasiados intentos fallidos. Tu cuenta se ha bloqueado por 4 minuto.');</script>";
                } else {
                    echo "<script>alert('Contraseña incorrecta. Intento $new_attempts de 3.');</script>";
                }

                $update = "UPDATE tblusers 
                           SET login_attempts = :attempts, account_locked_until = :lock_until 
                           WHERE id = :id";
                $stmt = $dbh->prepare($update);
                $stmt->bindParam(':attempts', $new_attempts, PDO::PARAM_INT);
                $stmt->bindParam(':lock_until', $lock_time, PDO::PARAM_STR);
                $stmt->bindParam(':id', $user->id, PDO::PARAM_INT);
                $stmt->execute();
            }
        }
    } else {
        echo "<script>alert('No existe una cuenta con ese correo electrónico.');</script>";
    }
}
?>

<!-- FORMULARIO MODAL -->
<div class="modal fade" id="myModal4" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content modal-info">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>						
            </div>
            <div class="modal-body modal-spa">
                <div class="login-grids">
                    <div class="login">
                        <div class="login-left">
                            <ul>
                                <li><a class="fb" href="#"><i></i>Facebook</a></li>
                                <li><a class="goog" href="#"><i></i>Google</a></li>
                            </ul>
                        </div>
                        <div class="login-right">
                            <form method="post">
                                <h3>Iniciar sesión con su cuenta</h3>
                                <input type="text" name="email" id="email" placeholder="Introduce tu correo electrónico" required="">	
                                <input type="password" name="password" id="password" placeholder="Contraseña" required="">	
                                <h4><a href="forgot-password.php">¿Has olvidado tu contraseña?</a></h4>
                                <a href="#" onclick="abrirRegistroDesdeLogin()">¿No tienes cuenta? Regístrate</a>
                                
                                <div class="modal fade" id="myModal" tabindex="-1" role="dialog">
                                    <div class="modal-dialog modal-lg" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Registro</h5>
                                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                            </div>
                                            <div class="modal-body" style="height: 600px;">
                                                <iframe src="includes/signup.php" frameborder="0" style="width:100%; height:100%;"></iframe>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <script>
                                function abrirRegistroDesdeLogin() {
                                    $('#myModal4').modal('hide'); 
                                    setTimeout(function () {
                                        $('#myModal').modal('show'); 
                                    }, 500); 
                                }
                                </script>

                                <input type="submit" name="signin" value="INGRESAR">
                            </form>
                        </div>
                        <div class="clearfix"></div>								
                    </div>
                    <p>Al iniciar sesión, aceptas nuestros 
                        <a href="page.php?type=terms">Términos y condiciones</a> y 
                        <a href="page.php?type=privacy">Política de Privacidad</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
