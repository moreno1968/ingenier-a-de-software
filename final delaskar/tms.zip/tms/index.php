<?php
session_start();
error_reporting(0);
include('includes/config.php');
?>
<!DOCTYPE HTML>
<html>
<head>
<title> Sistema de Gestión Turística</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
 <!-- Font Awesome 6 desde CDN -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

  <!-- Estilos compactos -->
  <style>
    .rupes {
      display: flex;
      gap: 20px;
      justify-content: space-between;
      padding: 20px;
      flex-wrap: wrap;
    }

    .rupes-left {
      display: flex;
      align-items: center;
      background-color: #f5f5f5;
      border-radius: 8px;
      padding: 10px 15px;
      max-width: 320px;
      flex: 1 1 300px;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }

    .rup-left {
      font-size: 24px;
      color: #007BFF;
      margin-right: 12px;
      min-width: 30px;
      text-align: center;
    }

    .rup-rgt h3 {
      font-size: 16px;
      margin: 0;
      font-weight: 600;
    }

    .rup-rgt h4 {
      font-size: 14px;
      margin: 2px 0 0;
    }

    .rup-rgt h4 a {
      text-decoration: none;
      color: #333;
    }

    .rup-rgt h4 a:hover {
      text-decoration: underline;
    }
  </style>
<link href="css/font-awesome.css" rel="stylesheet">

<script src="js/jquery-1.12.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>

<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>

</head>
<body>
<?php include('includes/header.php');?>
<div class="banner">
	<div class="container">
		<h1 class="wow zoomIn animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;"> Descubre los mejores destinos turísticos del Chocó
Explora playas, cascadas, parques naturales y mucho más</h1>
	</div>
</div>



<div class="container">
	<div class="rupes">
		<div class="col-md-4 rupes-left wow fadeInDown animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;">
			<div class="rup-left">
				<a href="offers.html"><i class="fa fa-fish fa-2x"></i></a>
			</div>
			<div class="rup-rgt">
				<h3>DONDE LA SELVA CANTA,EL RÍO DANZA Y EL MAR ABRAZA.</h3>
				<h4><a href="offers.html">EXPERIENCIAS AUTÉNTICAS ENTRE PLAYAS VÍRGENES, SELVAS TROPICALES Y COMUNIDADES QUE CONSERVAN SUS TRADICIONES.</a></h4>
				
			</div>
				<div class="clearfix"></div>
		</div>
		<div class="col-md-4 rupes-left wow fadeInDown animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;">
			<div class="rup-left">
				<a href="offers.html"><i class="fa fa-plane fa-2x"></i></a>
			</div>
			<div class="rup-rgt">
				<h3>CHOCO, UN TESORO ESCONDIDO ENTRE EL VERDE Y EL AZUL.</h3>
				<h4><a href="offers.html">DESDE NUQUI HASTA BAHIA SOLANO , CADA RINCON GUARDA UNA HISTORIA , UNA SONRISA Y UNA AVENTURA QUE TE ESPERA.</a></h4>
				
			</div>
				<div class="clearfix"></div>
		</div>
		<div class="col-md-4 rupes-left wow fadeInDown animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;">
			<div class="rup-left">
				<a href="offers.html"><i class="fa fa-globe fa-2x"></i></a>
			</div>
			<div class="rup-rgt">
				<h3>DONDE EL PACÍFICO COBRA VIDA.</h3>
				<h4><a href="offers.html">SUMERGETE EN UN PARAISO DE BIODIVERSIDAD, CULTURAS ANCESTRALES Y PAISAJES QUE QUITAN EL ALIENTO.</a></h4>
			
			</div>
				<div class="clearfix"></div>
		</div>
	
	</div>
</div>
<div class="container">
	<div class="holiday">
	
	<h3>Lista de sitios turisticos</h3>
	<?php
session_start();
error_reporting(0);
include('includes/config.php');

// Obtener el tipo de filtro si existe
$filterType = isset($_GET['type']) ? $_GET['type'] : '';
?>


<div class="container">
    <div class="holiday">
        
        
       <!-- Filtro por tipo de sitio - Versión mejorada -->
<div class="filter-section" style="margin-bottom: 20px;">
  <form method="get" action="" style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
    <label for="type" style="margin: 0; font-weight: bold; white-space: nowrap; line-height: 1.5;">Filtrar por tipo:</label>
    
    <select name="type" id="type" onchange="this.form.submit()" 
            style="padding: 8px 12px; border-radius: 4px; border: 1px solid #ccc; min-width: 200px;">
      <option value="">Todos los tipos</option>
      <?php
      $typeSql = "SELECT DISTINCT PackageType FROM tbltourpackages";
      $typeQuery = $dbh->prepare($typeSql);
      $typeQuery->execute();
      $types = $typeQuery->fetchAll(PDO::FETCH_OBJ);
      
      foreach($types as $type) {
          $selected = ($filterType == $type->PackageType) ? 'selected' : '';
          echo '<option value="'.htmlentities($type->PackageType).'" '.$selected.'>'.htmlentities($type->PackageType).'</option>';
      }
      ?>
    </select>

    <noscript>
      <input type="submit" value="Filtrar" style="padding: 8px 16px; background-color: #4CAF50; color: white; border: none; border-radius: 4px; cursor: pointer;">
    </noscript>
  </form>
</div>



        <?php 
        // Construir 
        $sql = "SELECT * FROM tbltourpackages";
        $params = array();
        
        if(!empty($filterType)) {
            $sql .= " WHERE PackageType = :type";
            $params[':type'] = $filterType;
        }
        $sql .= " ORDER BY rand() LIMIT 4";
        
        $query = $dbh->prepare($sql);
        
        // Bind de parámetros
        foreach($params as $key => &$val) {
            $query->bindParam($key, $val);
        }
        
        $query->execute();
        $results = $query->fetchAll(PDO::FETCH_OBJ);
        
        if($query->rowCount() > 0) {
            foreach($results as $result) { 
        ?>
            <div class="rom-btm">-
                <div class="col-md-3  room-left wow fadeInLeft animated" data-wow-delay=".5s">
                    <img src="admin/pacakgeimages/<?php echo htmlentities($result->PackageImage); ?>" class="img-responsive" alt="">
                </div>
                <div class="col-md-6 room-midle wow fadeInUp animated" data-wow-delay=".5s">
                    <h4>Nombre del sitio: <?php echo htmlentities($result->PackageName); ?></h4>
                    <h6>Tipo del sitio: <?php echo htmlentities($result->PackageType); ?></h6>
                    <p><b>Ubicación del sitio:</b> <?php echo htmlentities($result->PackageLocation); ?></p>
                    <p><b>Características</b> <?php echo htmlentities($result->PackageFetures); ?></p>
                </div>
                <div class="col-md-3 room-right wow fadeInRight animated" data-wow-delay=".5s">
                    <h5><?php echo htmlentities($result->PackagePrice); ?></h5>
                    <a href="package-details.php?pkgid=<?php echo htmlentities($result->PackageId); ?>" class="view">Detalles</a>
                </div>
                <div class="clearfix"></div>
            </div>
        <?php 
            } 
        } else {
            echo '<div class="alert alert-info">No se encontraron resultados para el tipo seleccionado.</div>';
        }
        ?>
        
        <div style="margin-top: 20px;">
            <a href="package-list.php?type=<?php echo urlencode($filterType); ?>" class="view">Ver más sitios</a>
        </div>
    </div>
    <div class="clearfix"></div>
</div>
<div class="routes">
	<div class="container">
		<div class="col-md-4 routes-left wow fadeInRight animated" data-wow-delay=".5s">
			<div class="rou-left">
				<a href="#"><i class="glyphicon glyphicon-list-alt"></i></a>
			</div>
			<div class="rou-rgt wow fadeInDown animated" data-wow-delay=".5s">
				<h3>80</h3>
				<p>Consultas</p>
			</div>
				<div class="clearfix"></div>
		</div>
		<div class="col-md-4 routes-left">
			<div class="rou-left">
				<a href="#"><i class="fa fa-user"></i></a>
			</div>
			<div class="rou-rgt">
				<h3>1900</h3>
				<p>Usuarios registrados</p>
			</div>
				<div class="clearfix"></div>
		</div>
		<div class="col-md-4 routes-left wow fadeInRight animated" data-wow-delay=".5s">
			<div class="rou-left">
				<a href="#"><i class="fa fa-ticket"></i></a>
			</div>
			<div class="rou-rgt">
				<h3>700+</h3>
				<p>sitios favoritos</p>
			</div>
				<div class="clearfix"></div>
		</div>
		<div class="clearfix"></div>
	</div>
</div>

<?php include('includes/footer.php');?>

<?php include('includes/signup.php');?>			

<?php include('includes/signin.php');?>			

<?php include('includes/write-us.php');?>			

</body>
</html>